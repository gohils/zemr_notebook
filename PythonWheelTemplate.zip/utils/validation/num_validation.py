
def validate1(df):
    result = "data is validated with rule list 1"
    print(result)
    return result


def validate2(df):
    result = "data is validated with rule list 2"
    print(result)
    return result