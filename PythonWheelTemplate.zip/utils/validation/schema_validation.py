
def validate_schema1(df):
    result = "data is validated with schema1 successfully"
    print(result)
    return result


def validate_schema2(df):
    result = "data is validated with schema1 successfully"
    print(result)
    return result