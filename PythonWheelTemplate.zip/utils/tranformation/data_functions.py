
def tranform1(df):
    result = "data is tranformed with function1"
    print(result)
    return result


def tranform2(df):
    result = "data is tranformed with function2"
    print(result)
    return result