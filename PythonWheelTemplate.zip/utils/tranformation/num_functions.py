
def add_two(a,b):
    result = a + b
    print(result)
    return result


def multiply_two(a,b):
    result = a * b
    print(result)
    return result