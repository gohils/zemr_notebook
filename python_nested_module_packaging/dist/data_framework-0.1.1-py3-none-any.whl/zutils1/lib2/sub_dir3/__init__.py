# expose class for calling outside the package with import
from .module1 import Module1Class1
# expose module for calling outside the package with import
from . import module2
